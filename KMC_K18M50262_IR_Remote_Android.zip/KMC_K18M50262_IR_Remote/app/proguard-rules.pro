# Keep IR remote classes intact
-keep class com.kmc.remote.** { *; }
