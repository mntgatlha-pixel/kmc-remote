package com.kmc.remote

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var irManager: ConsumerIrManager? = null
    private var currentProfileIndex = 0
    private val prefsName = "kmc_remote_prefs"
    private val keyProfileIndex = "profile_index"

    private lateinit var tvStatus: TextView
    private lateinit var tvIrLed: View
    private lateinit var spinnerProfile: Spinner
    private lateinit var btnAutoScan: Button

    private val handler = Handler(Looper.getMainLooper())
    private var isScanning = false
    private var scanStep = 0

    private val scanRunnable = object : Runnable {
        override fun run() {
            if (!isScanning) return
            if (scanStep >= KmcProfiles.ALL.size) {
                stopAutoScan(found = false)
                return
            }
            currentProfileIndex = scanStep
            spinnerProfile.setSelection(scanStep)
            val profile = KmcProfiles.ALL[scanStep]
            tvStatus.text = "جاري اختبار ${profile.titleAr} ... اضغط (إيقاف) فور استجابة الشاشة"
            sendButton(RemoteButton.POWER, silentStatus = true)
            scanStep++
            handler.postDelayed(this, 1600L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        irManager = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

        tvStatus = findViewById(R.id.tvStatus)
        tvIrLed = findViewById(R.id.viewIrLed)
        spinnerProfile = findViewById(R.id.spinnerProfile)
        btnAutoScan = findViewById(R.id.btnAutoScan)

        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        currentProfileIndex = prefs.getInt(keyProfileIndex, 0)
            .coerceIn(0, KmcProfiles.ALL.lastIndex)

        setupProfileSpinner()
        setupButtons()
        checkIrHardware()
    }

    private fun checkIrHardware() {
        val hasIr = irManager?.hasIrEmitter() == true
        if (hasIr) {
            val profile = KmcProfiles.ALL[currentProfileIndex]
            tvStatus.text = "جاهز للإرسال (38kHz NEC) • ${profile.titleAr}"
        } else {
            tvStatus.text = "تنبيه: لم يتم اكتشاف منفذ IR مدمج — إذا كنت تستخدم قطعة IR خارجية تأكد من تفعيلها"
        }
    }

    private fun setupProfileSpinner() {
        val titles = KmcProfiles.ALL.map { it.titleAr }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, titles)
        spinnerProfile.adapter = adapter
        spinnerProfile.setSelection(currentProfileIndex)

        spinnerProfile.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentProfileIndex = position
                getSharedPreferences(prefsName, Context.MODE_PRIVATE)
                    .edit()
                    .putInt(keyProfileIndex, position)
                    .apply()
                if (!isScanning) {
                    tvStatus.text = "الملف النشط: ${KmcProfiles.ALL[position].descriptionAr}"
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
    }

    private fun setupButtons() {
        val mapping = mapOf(
            R.id.btnPower to RemoteButton.POWER,
            R.id.btnMute to RemoteButton.MUTE,
            R.id.btnSource to RemoteButton.SOURCE,
            R.id.btn0 to RemoteButton.NUM_0,
            R.id.btn1 to RemoteButton.NUM_1,
            R.id.btn2 to RemoteButton.NUM_2,
            R.id.btn3 to RemoteButton.NUM_3,
            R.id.btn4 to RemoteButton.NUM_4,
            R.id.btn5 to RemoteButton.NUM_5,
            R.id.btn6 to RemoteButton.NUM_6,
            R.id.btn7 to RemoteButton.NUM_7,
            R.id.btn8 to RemoteButton.NUM_8,
            R.id.btn9 to RemoteButton.NUM_9,
            R.id.btnRecall to RemoteButton.RECALL,
            R.id.btnInfo to RemoteButton.INFO,
            R.id.btnVolUp to RemoteButton.VOL_UP,
            R.id.btnVolDown to RemoteButton.VOL_DOWN,
            R.id.btnChUp to RemoteButton.CH_UP,
            R.id.btnChDown to RemoteButton.CH_DOWN,
            R.id.btnUp to RemoteButton.UP,
            R.id.btnDown to RemoteButton.DOWN,
            R.id.btnLeft to RemoteButton.LEFT,
            R.id.btnRight to RemoteButton.RIGHT,
            R.id.btnOk to RemoteButton.OK,
            R.id.btnMenu to RemoteButton.MENU,
            R.id.btnExit to RemoteButton.EXIT,
            R.id.btnAspect to RemoteButton.ASPECT,
            R.id.btnSleep to RemoteButton.SLEEP,
            R.id.btnPlayPause to RemoteButton.PLAY_PAUSE,
            R.id.btnStop to RemoteButton.STOP,
            R.id.btnPrev to RemoteButton.PREV,
            R.id.btnNext to RemoteButton.NEXT,
            R.id.btnRed to RemoteButton.RED,
            R.id.btnGreen to RemoteButton.GREEN,
            R.id.btnYellow to RemoteButton.YELLOW,
            R.id.btnBlue to RemoteButton.BLUE
        )

        mapping.forEach { (viewId, remoteButton) ->
            findViewById<View>(viewId)?.setOnClickListener {
                if (isScanning) stopAutoScan(found = true)
                sendButton(remoteButton)
            }
        }

        btnAutoScan.setOnClickListener {
            if (isScanning) {
                stopAutoScan(found = true)
            } else {
                startAutoScan()
            }
        }

        findViewById<Button>(R.id.btnCustomHex).setOnClickListener {
            showCustomHexDialog()
        }
    }

    private fun startAutoScan() {
        isScanning = true
        scanStep = 0
        btnAutoScan.text = "إيقاف وحفظ الملف"
        handler.post(scanRunnable)
    }

    private fun stopAutoScan(found: Boolean) {
        isScanning = false
        handler.removeCallbacks(scanRunnable)
        btnAutoScan.text = "فحص تلقائي (Auto-Scan)"
        val savedIndex = (if (found && scanStep > 0) scanStep - 1 else currentProfileIndex)
            .coerceIn(0, KmcProfiles.ALL.lastIndex)
        currentProfileIndex = savedIndex
        spinnerProfile.setSelection(savedIndex)
        getSharedPreferences(prefsName, Context.MODE_PRIVATE)
            .edit()
            .putInt(keyProfileIndex, savedIndex)
            .apply()
        tvStatus.text = if (found) {
            "تم حفظ: ${KmcProfiles.ALL[savedIndex].titleAr}"
        } else {
            "انتهى الفحص التلقائي — يمكنك تجربة مختبر كود HEX اليدوي"
        }
    }

    private fun sendButton(button: RemoteButton, silentStatus: Boolean = false) {
        vibrateShort()
        blinkLed()

        val profile = KmcProfiles.ALL[currentProfileIndex]
        val pattern = profile.encodeButton(button) ?: return

        if (!silentStatus) {
            tvStatus.text = "إرسال ${button.name} • ${profile.formatHex(button)}"
        }

        transmitPattern(pattern)
    }

    private fun transmitPattern(pattern: IntArray) {
        val manager = irManager
        if (manager == null || !manager.hasIrEmitter()) {
            Toast.makeText(this, "لا يوجد مرسل IR مدمج في هذا الهاتف", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            manager.transmit(NecIrEncoder.CARRIER_FREQUENCY_HZ, pattern)
        } catch (e: Exception) {
            tvStatus.text = "خطأ في الإرسال: ${e.localizedMessage}"
        }
    }

    private fun showCustomHexDialog() {
        val input = EditText(this).apply {
            hint = "مثال: 00FF08F7 أو 40BF0BF4"
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("إرسال كود NEC HEX مخصص")
            .setMessage("أدخل كود NEC مكون من 8 خانات Hex (32-bit) للتجربة المباشرة:")
            .setView(input)
            .setPositiveButton("إرسال") { _, _ ->
                val raw = input.text.toString().trim().removePrefix("0x").removePrefix("0X")
                val parsed = raw.toLongOrNull(16)
                if (parsed == null || raw.length != 8) {
                    Toast.makeText(this, "يرجى إدخال 8 خانات HEX صحيحة", Toast.LENGTH_SHORT).show()
                } else {
                    vibrateShort()
                    blinkLed()
                    val pattern = NecIrEncoder.encodeRaw32Msb(parsed)
                    tvStatus.text = "إرسال مخصص: 0x${raw.uppercase()}"
                    transmitPattern(pattern)
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun blinkLed() {
        tvIrLed.alpha = 1.0f
        handler.postDelayed({ tvIrLed.alpha = 0.2f }, 140L)
    }

    @Suppress("DEPRECATION")
    private fun vibrateShort() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            vibrator.vibrate(25)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(scanRunnable)
    }
}
