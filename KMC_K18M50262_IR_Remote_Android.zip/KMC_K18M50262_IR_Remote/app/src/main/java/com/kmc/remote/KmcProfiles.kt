package com.kmc.remote

enum class RemoteButton {
    POWER, MUTE, SOURCE,
    NUM_0, NUM_1, NUM_2, NUM_3, NUM_4, NUM_5, NUM_6, NUM_7, NUM_8, NUM_9,
    RECALL, INFO,
    VOL_UP, VOL_DOWN, CH_UP, CH_DOWN,
    UP, DOWN, LEFT, RIGHT, OK,
    MENU, EXIT, ASPECT, SLEEP,
    PLAY_PAUSE, STOP, PREV, NEXT,
    RED, GREEN, YELLOW, BLUE
}

data class IrProfile(
    val id: String,
    val titleAr: String,
    val descriptionAr: String,
    val addrLow: Int,
    val addrHigh: Int,
    val commands: Map<RemoteButton, Int>
) {
    fun encodeButton(button: RemoteButton): IntArray? {
        val cmd = commands[button] ?: return null
        return NecIrEncoder.encodeExtended(addrLow, addrHigh, cmd)
    }

    fun formatHex(button: RemoteButton): String {
        val cmd = commands[button] ?: return "--"
        val cmdInv = cmd.inv() and 0xFF
        return String.format("0x%02X%02X%02X%02X", addrLow, addrHigh, cmd, cmdInv)
    }
}

/**
 * Curated NEC 38kHz IR profiles for KMC LED TVs (Model K18M50262 / 50" FHD LED)
 * and compatible Chinese OEM chassis (Changhong / MStar / TP.V56 / TP.MS3663 / CV512H).
 */
object KmcProfiles {

    private val standardChineseTvMap = mapOf(
        RemoteButton.POWER to 0x08,
        RemoteButton.MUTE to 0x09,
        RemoteButton.SOURCE to 0x0B,
        RemoteButton.NUM_0 to 0x10,
        RemoteButton.NUM_1 to 0x11,
        RemoteButton.NUM_2 to 0x12,
        RemoteButton.NUM_3 to 0x13,
        RemoteButton.NUM_4 to 0x14,
        RemoteButton.NUM_5 to 0x15,
        RemoteButton.NUM_6 to 0x16,
        RemoteButton.NUM_7 to 0x17,
        RemoteButton.NUM_8 to 0x18,
        RemoteButton.NUM_9 to 0x19,
        RemoteButton.RECALL to 0x1A,
        RemoteButton.INFO to 0x1B,
        RemoteButton.VOL_UP to 0x02,
        RemoteButton.VOL_DOWN to 0x03,
        RemoteButton.CH_UP to 0x00,
        RemoteButton.CH_DOWN to 0x01,
        RemoteButton.UP to 0x40,
        RemoteButton.DOWN to 0x41,
        RemoteButton.LEFT to 0x07,
        RemoteButton.RIGHT to 0x06,
        RemoteButton.OK to 0x44,
        RemoteButton.MENU to 0x43,
        RemoteButton.EXIT to 0x5B,
        RemoteButton.ASPECT to 0x52,
        RemoteButton.SLEEP to 0x0E,
        RemoteButton.PLAY_PAUSE to 0x48,
        RemoteButton.STOP to 0x49,
        RemoteButton.PREV to 0x4A,
        RemoteButton.NEXT to 0x4B,
        RemoteButton.RED to 0x50,
        RemoteButton.GREEN to 0x51,
        RemoteButton.YELLOW to 0x52,
        RemoteButton.BLUE to 0x53
    )

    private val mstarCv512Map = mapOf(
        RemoteButton.POWER to 0x0B,
        RemoteButton.MUTE to 0x0E,
        RemoteButton.SOURCE to 0x0C,
        RemoteButton.NUM_0 to 0x00,
        RemoteButton.NUM_1 to 0x01,
        RemoteButton.NUM_2 to 0x02,
        RemoteButton.NUM_3 to 0x03,
        RemoteButton.NUM_4 to 0x04,
        RemoteButton.NUM_5 to 0x05,
        RemoteButton.NUM_6 to 0x06,
        RemoteButton.NUM_7 to 0x07,
        RemoteButton.NUM_8 to 0x08,
        RemoteButton.NUM_9 to 0x09,
        RemoteButton.RECALL to 0x0A,
        RemoteButton.INFO to 0x16,
        RemoteButton.VOL_UP to 0x1A,
        RemoteButton.VOL_DOWN to 0x1E,
        RemoteButton.CH_UP to 0x1B,
        RemoteButton.CH_DOWN to 0x1F,
        RemoteButton.UP to 0x19,
        RemoteButton.DOWN to 0x1D,
        RemoteButton.LEFT to 0x42,
        RemoteButton.RIGHT to 0x40,
        RemoteButton.OK to 0x15,
        RemoteButton.MENU to 0x12,
        RemoteButton.EXIT to 0x14,
        RemoteButton.ASPECT to 0x4A,
        RemoteButton.SLEEP to 0x11,
        RemoteButton.PLAY_PAUSE to 0x4C,
        RemoteButton.STOP to 0x4D,
        RemoteButton.PREV to 0x4E,
        RemoteButton.NEXT to 0x4F,
        RemoteButton.RED to 0x50,
        RemoteButton.GREEN to 0x51,
        RemoteButton.YELLOW to 0x52,
        RemoteButton.BLUE to 0x53
    )

    private val tpV56Map = mapOf(
        RemoteButton.POWER to 0x12,
        RemoteButton.MUTE to 0x10,
        RemoteButton.SOURCE to 0x0F,
        RemoteButton.NUM_0 to 0x00,
        RemoteButton.NUM_1 to 0x01,
        RemoteButton.NUM_2 to 0x02,
        RemoteButton.NUM_3 to 0x03,
        RemoteButton.NUM_4 to 0x04,
        RemoteButton.NUM_5 to 0x05,
        RemoteButton.NUM_6 to 0x06,
        RemoteButton.NUM_7 to 0x07,
        RemoteButton.NUM_8 to 0x08,
        RemoteButton.NUM_9 to 0x09,
        RemoteButton.RECALL to 0x1E,
        RemoteButton.INFO to 0x13,
        RemoteButton.VOL_UP to 0x1A,
        RemoteButton.VOL_DOWN to 0x1B,
        RemoteButton.CH_UP to 0x1C,
        RemoteButton.CH_DOWN to 0x1D,
        RemoteButton.UP to 0x14,
        RemoteButton.DOWN to 0x15,
        RemoteButton.LEFT to 0x16,
        RemoteButton.RIGHT to 0x17,
        RemoteButton.OK to 0x18,
        RemoteButton.MENU to 0x19,
        RemoteButton.EXIT to 0x1F,
        RemoteButton.ASPECT to 0x20,
        RemoteButton.SLEEP to 0x21,
        RemoteButton.PLAY_PAUSE to 0x40,
        RemoteButton.STOP to 0x41,
        RemoteButton.PREV to 0x42,
        RemoteButton.NEXT to 0x43,
        RemoteButton.RED to 0x44,
        RemoteButton.GREEN to 0x45,
        RemoteButton.YELLOW to 0x46,
        RemoteButton.BLUE to 0x47
    )

    val ALL: List<IrProfile> = listOf(
        IrProfile(
            id = "kmc_changhong_00ff",
            titleAr = "ملف 1: KMC / Changhong (0x00FF)",
            descriptionAr = "الأكثر شيوعاً لشاشات KMC 50 بوصة (كود 001)",
            addrLow = 0x00,
            addrHigh = 0xFF,
            commands = standardChineseTvMap
        ),
        IrProfile(
            id = "kmc_mstar_40bf",
            titleAr = "ملف 2: KMC / MStar (0x40BF)",
            descriptionAr = "لوحات MStar و CV512H الصينية",
            addrLow = 0x40,
            addrHigh = 0xBF,
            commands = mstarCv512Map
        ),
        IrProfile(
            id = "kmc_tpv56_00bf",
            titleAr = "ملف 3: لوحة TP.V56 / MS3663 (0x00BF)",
            descriptionAr = "لوحات LED الصينية الشاملة 2018",
            addrLow = 0x00,
            addrHigh = 0xBF,
            commands = tpV56Map
        ),
        IrProfile(
            id = "kmc_oem_04fb",
            titleAr = "ملف 4: شاشات OEM قياسي (0x04FB)",
            descriptionAr = "كود NEC القياسي للشاشات المجمعة",
            addrLow = 0x04,
            addrHigh = 0xFB,
            commands = standardChineseTvMap
        ),
        IrProfile(
            id = "kmc_oem_02fd",
            titleAr = "ملف 5: لوحة Changhong بديل (0x02FD)",
            descriptionAr = "بديل Changhong / DLC / KMC",
            addrLow = 0x02,
            addrHigh = 0xFD,
            commands = mstarCv512Map
        ),
        IrProfile(
            id = "kmc_oem_20df",
            titleAr = "ملف 6: كود بديل (0x20DF)",
            descriptionAr = "متوافق مع عدة شاشات آسيوية",
            addrLow = 0x20,
            addrHigh = 0xDF,
            commands = standardChineseTvMap
        ),
        IrProfile(
            id = "kmc_oem_08f7",
            titleAr = "ملف 7: كود صيني بديل (0x08F7)",
            descriptionAr = "متوافق مع دفعات KMC / ATC / Nikai",
            addrLow = 0x08,
            addrHigh = 0xF7,
            commands = tpV56Map
        )
    )
}
