package com.kmc.remote

/**
 * Standard NEC / Extended-NEC 38kHz Infrared Pulse Encoder for Android ConsumerIrManager.
 *
 * Frame format (microseconds):
 * - Header Mark:  9000 us
 * - Header Space: 4500 us
 * - 32 bits (LSB first per byte):
 *     - Logical '0': 560 us Mark,  560 us Space
 *     - Logical '1': 560 us Mark, 1690 us Space
 * - Trailing Stop Mark: 560 us
 */
object NecIrEncoder {
    const val CARRIER_FREQUENCY_HZ = 38000

    private const val HEADER_MARK = 9000
    private const val HEADER_SPACE = 4500
    private const val BIT_MARK = 560
    private const val ONE_SPACE = 1690
    private const val ZERO_SPACE = 560
    private const val STOP_MARK = 560

    /**
     * Encodes an 8-bit NEC address (auto-inverted) and 8-bit command (auto-inverted).
     */
    fun encodeStandard(address: Int, command: Int): IntArray {
        val addrLow = address and 0xFF
        val addrHigh = addrLow.inv() and 0xFF
        return encodeExtended(addrLow, addrHigh, command)
    }

    /**
     * Encodes a 16-bit Extended NEC address (addrLow, addrHigh) and 8-bit command (auto-inverted).
     */
    fun encodeExtended(addrLow: Int, addrHigh: Int, command: Int): IntArray {
        val cmd = command and 0xFF
        val cmdInv = cmd.inv() and 0xFF
        val bytes = intArrayOf(addrLow and 0xFF, addrHigh and 0xFF, cmd, cmdInv)
        return buildPatternFromBytes(bytes)
    }

    /**
     * Encodes a raw 32-bit NEC hex code in standard MSB-first notation (e.g., 0x00FF10EF).
     * Byte order: [addr1, addr2, cmd, ~cmd] transmitted MSB-first as used in LIRC / Arduino IRremote.
     */
    fun encodeRaw32Msb(hexCode: Long): IntArray {
        val pattern = IntArray(67)
        var idx = 0
        pattern[idx++] = HEADER_MARK
        pattern[idx++] = HEADER_SPACE

        for (bit in 31 downTo 0) {
            pattern[idx++] = BIT_MARK
            val isOne = ((hexCode shr bit) and 1L) == 1L
            pattern[idx++] = if (isOne) ONE_SPACE else ZERO_SPACE
        }
        pattern[idx] = STOP_MARK
        return pattern
    }

    private fun buildPatternFromBytes(bytes: IntArray): IntArray {
        val pattern = IntArray(67)
        var idx = 0
        pattern[idx++] = HEADER_MARK
        pattern[idx++] = HEADER_SPACE

        for (b in bytes) {
            for (bit in 0 until 8) {
                pattern[idx++] = BIT_MARK
                val isOne = ((b shr bit) and 1) == 1
                pattern[idx++] = if (isOne) ONE_SPACE else ZERO_SPACE
            }
        }
        pattern[idx] = STOP_MARK
        return pattern
    }
}
